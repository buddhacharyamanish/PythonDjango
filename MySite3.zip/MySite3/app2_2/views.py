from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'app2_2/index.html')

#http://127.0.0.1:8000/app2_2/getValues1?pid=1&name=aaa&address=Teku
def getValues1(request):
    #return HttpResponse("Welcome to getValues1")
    pid = request.GET.get('pid')
    #pid = int(pid)
    #pid += 1
    #print("pid ", pid)
    name = request.GET.get('name')
    address = request.GET['address']
    data = {'pid':pid,'name':name,'address':address}
    # Write on data file (Text file)
    # Insert on database table
    # Write on XML file
    # Write on init file
    # Write on pdf file
    str1="<h1>Personal Info</h1>"
    str1 = str1+"PID : "+str(pid)+"<br/>";
    str1 = str1+ "NAME : "+name+"<br/>"
    str1 = str1 + "ADDRESS : " + address + "<br/>"
    return HttpResponse(str1)

def getValues2(request):
    pid = request.GET['txt1']
    name = request.GET['txt2']
    address = request.GET['txt3']
    str1 = "<h1>Personal Info</h1>"
    str1 = str1 + "PID : " + str(pid) + "<br/>";
    str1 = str1 + "NAME : " + name + "<br/>"
    str1 = str1 + "ADDRESS : " + address + "<br/>"
    return HttpResponse(str1)

def getValues3(request):
    pid = request.POST['txt1']
    name = request.POST['txt2']
    address = request.POST['txt3']
    str1 = "<h1>Personal Info</h1>"
    str1 = str1 + "PID : " + str(pid) + "<br/>";
    str1 = str1 + "NAME : " + name + "<br/>"
    str1 = str1 + "ADDRESS : " + address + "<br/>"
    return HttpResponse(str1)

# URL : http://127.0.0.1:8000/app2_2/getValues4/1/manish/kathmandu/<Enter>
def getValues4(request, pid,name,address):
    str1 = "<h1>Personal Info</h>"
    str1+="PID : {} </br>".format(pid)
    str1 += "NAME : {} </br>".format(name)
    str1 += "ADDRESS : {} </br>".format(address)
    return HttpResponse(str1)