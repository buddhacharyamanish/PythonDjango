from django.shortcuts import render
from django.http import HttpResponse #Output library #1

# Create your views here.
# View function #2

#View function #2
def index(request):
    return HttpResponse("Hello from app1_1 -> index()");