from django.urls import path
from app2_3.views import *

urlpatterns = [
    path('index/', index),
]