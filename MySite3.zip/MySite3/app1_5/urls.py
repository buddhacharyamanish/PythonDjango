from django.urls import path
from app1_5.views import *

urlpatterns = [
    path('index/', index),
]