from django.shortcuts import render
from django.http import HttpResponse # text (html tags) -> output

# Create your views here.

def index(request):
    return render(request, 'app1_5/index.html')